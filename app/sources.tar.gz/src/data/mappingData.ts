export interface MappingRow { pset: string; ifc: string; type: string; fop: string; mge: string; example: string }
export interface MappingSection { title: string; ifcClass: string; rows: MappingRow[] }

export const mappingSections: MappingSection[] = [
  {
    "title": "Требования для всех элементов, выгружаемых в IFC",
    "ifcClass": "",
    "rows": [
      {
        "pset": "",
        "ifc": "MGE_ElementCode",
        "type": "Text",
        "fop": "ОП_Код по классификатору",
        "mge": "МГЭ_Код элемента (код по классификатору МССК «Элементы»)",
        "example": "ЭЛ 30 30 10"
      }
    ]
  },
  {
    "title": "Объект (здание, корпус)",
    "ifcClass": "IfcBuilding",
    "rows": [
      {
        "pset": "Общие параметры ЦИМ (по п. 9.2 «Общих требований к ЦИМ»)",
        "ifc": "MGE_ElementCode",
        "type": "Text",
        "fop": "ОП_Код по классификатору",
        "mge": "МГЭ_Код элемента",
        "example": "ЭЛ 30 30 20"
      }
    ]
  },
  {
    "title": "Зона (СПП в ГНС)",
    "ifcClass": "IfcSpace",
    "rows": []
  },
  {
    "title": "Зона (Общая площадь)",
    "ifcClass": "IfcSpace",
    "rows": []
  },
  {
    "title": "Зона (пожарный отсек, автостоянка)",
    "ifcClass": "IfcSpace",
    "rows": [
      {
        "pset": "Pset_SpaceCommon",
        "ifc": "HandicapAccessible",
        "type": "Boolean",
        "fop": "ОП_Доступность МГН",
        "mge": "Доступность МГН",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_SpaceCommon",
        "ifc": "IsExternal",
        "type": "Boolean",
        "fop": "ОП_Наружный",
        "mge": "Признак наружного пространства",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_ZoneCode",
        "type": "Text",
        "fop": "ОП_Код по классификатору",
        "mge": "МГЭ_Код зоны (по МССК «Помещения и зоны»)",
        "example": "ПЗ 10 10 10"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_Name",
        "type": "Text",
        "fop": "ADSK_Наименование",
        "mge": "МГЭ_Имя",
        "example": "Зона общей площади"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_LongName",
        "type": "Text",
        "fop": "ОП_Описание",
        "mge": "МГЭ_Описание",
        "example": "Общая площадь надземной части здания"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_SpaceN",
        "type": "Text",
        "fop": "ОП_Номер зоны",
        "mge": "МГЭ_Номер зоны",
        "example": "1 (для неизолированного пожарного отсека — 1н)"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_Section",
        "type": "Text",
        "fop": "ADSK_Номер секции",
        "mge": "МГЭ_Секция",
        "example": "Секция 1"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_UsingCode",
        "type": "Text",
        "fop": "ОП_Код назначения",
        "mge": "МГЭ_Код назначения (по МССК «Назначение и виды деятельности»)",
        "example": "01 01 10"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_Using",
        "type": "Text",
        "fop": "ОП_Назначение",
        "mge": "МГЭ_Назначение зоны",
        "example": "Зона общей площади"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_ZoneType",
        "type": "Text",
        "fop": "ОП_Тип зоны",
        "mge": "МГЭ_Тип зоны (из справочника «Типы помещений и зон», Приложение Б)",
        "example": "Общая площадь"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_FireResistance",
        "type": "Text",
        "fop": "ОП_Степень огнестойкости",
        "mge": "МГЭ_Степень огнестойкости (для зон пожарных отсеков)",
        "example": "II"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_FireRiskFactor_1",
        "type": "Text",
        "fop": "ОП_Класс конструктивной пожарной опасности",
        "mge": "МГЭ_Класс конструктивной пожарной опасности (для пожарных отсеков)",
        "example": "С0"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_FireRiskFactor_2",
        "type": "Text",
        "fop": "ОП_Класс функциональной пожарной опасности",
        "mge": "МГЭ_Класс функциональной пожарной опасности (для пожарных отсеков)",
        "example": "Ф1.3"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_ParkigSpace",
        "type": "Integer",
        "fop": "ОП_Вместимость автостоянки",
        "mge": "МГЭ_Вместимость автостоянки, машиномест (для зон автостоянок)",
        "example": "125"
      }
    ]
  },
  {
    "title": "Помещение",
    "ifcClass": "IfcSpace",
    "rows": [
      {
        "pset": "Pset_SpaceCommon",
        "ifc": "HandicapAccessible",
        "type": "Boolean",
        "fop": "ОП_Доступность МГН",
        "mge": "Доступность МГН",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_SpaceCommon",
        "ifc": "IsExternal",
        "type": "Boolean",
        "fop": "ОП_Наружный",
        "mge": "Признак наружного пространства",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "Pset_SpaceFireSafetyRequirements",
        "ifc": "FireRiskFactor",
        "type": "Text",
        "fop": "ОП_Категория по пожарной опасности",
        "mge": "Категория помещения по пожарной и взрывопожарной опасности (123-ФЗ ст. 27)",
        "example": "В1"
      },
      {
        "pset": "Pset_SpaceFireSafetyRequirements",
        "ifc": "AirPressurization",
        "type": "Boolean",
        "fop": "ОП_Подпор воздуха",
        "mge": "Подпор воздуха",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "Pset_SpaceFireSafetyRequirements",
        "ifc": "FireExit",
        "type": "Boolean",
        "fop": "ОП_Путь эвакуации",
        "mge": "Путь эвакуации (коридоры, лестничные клетки, вестибюли)",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_SpaceFireSafetyRequirements",
        "ifc": "SprinklerProtection",
        "type": "Boolean",
        "fop": "ОП_Система пожаротушения",
        "mge": "Система пожаротушения",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_SpaceFireSafetyRequirements",
        "ifc": "SprinklerProtectionAutomatic",
        "type": "Boolean",
        "fop": "ОП_Наличие АУПТ",
        "mge": "Наличие АУПТ",
        "example": "ИСТИНА"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_SpaceCode",
        "type": "Text",
        "fop": "ОП_Код по классификатору",
        "mge": "МГЭ_Код помещения (по МССК «Помещения и зоны»)",
        "example": "ПЗ 10 10 10"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_Name",
        "type": "Text",
        "fop": "ADSK_Наименование",
        "mge": "МГЭ_Имя",
        "example": "Жилая комната"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_LongName",
        "type": "Text",
        "fop": "ОП_Описание",
        "mge": "МГЭ_Описание",
        "example": "Жилая комната квартиры № 25"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_SpaceN",
        "type": "Text",
        "fop": "Номер",
        "mge": "МГЭ_Номер помещения по проекту",
        "example": "25.1"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_Section",
        "type": "Text",
        "fop": "ADSK_Номер секции",
        "mge": "МГЭ_Секция",
        "example": "Секция 1"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_UsingCode",
        "type": "Text",
        "fop": "ОП_Код назначения",
        "mge": "МГЭ_Код назначения (по МССК «Назначение и виды деятельности»)",
        "example": "01 01 10"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_Using",
        "type": "Text",
        "fop": "ОП_Назначение",
        "mge": "МГЭ_Назначение",
        "example": "Квартира"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_SpaceType",
        "type": "Text",
        "fop": "ОП_Тип помещения",
        "mge": "МГЭ_Тип помещения (справочник «Типы помещений и зон», Приложение Б)",
        "example": "Жилая комната"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_S_useful",
        "type": "Boolean",
        "fop": "ОП_Полезная площадь",
        "mge": "МГЭ_Полезная площадь",
        "example": "ИСТИНА"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_S_calc",
        "type": "Boolean",
        "fop": "ОП_Расчетная площадь",
        "mge": "МГЭ_Расчетная площадь",
        "example": "ИСТИНА"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_Atrium",
        "type": "Boolean",
        "fop": "ОП_Многосветное помещение",
        "mge": "МГЭ_Многосветное помещение",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_Wet",
        "type": "Boolean",
        "fop": "ОП_Мокрое помещение",
        "mge": "МГЭ_Мокрое помещение",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_FlatNumber",
        "type": "Text",
        "fop": "ОП_Номер квартиры сквозной",
        "mge": "МГЭ_Номер квартиры (для МКД)",
        "example": "25"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_FlatType",
        "type": "Text",
        "fop": "ОП_Тип квартиры",
        "mge": "МГЭ_Тип квартиры (стандарт / евро / студия / многоуровневая)",
        "example": "евро"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_NumRoom",
        "type": "Integer",
        "fop": "ОП_Количество комнат квартиры",
        "mge": "МГЭ_Количество комнат квартиры",
        "example": "2"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_Сapacity_const",
        "type": "Integer",
        "fop": "ОП_Количество людей постоянное пребывание",
        "mge": "МГЭ_Расчетное количество людей с постоянным пребыванием (общественные помещения)",
        "example": "30"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_Сapacity_temp",
        "type": "Integer",
        "fop": "ОП_Количество людей временное пребывание",
        "mge": "МГЭ_Расчетное количество людей с временным пребыванием",
        "example": "10"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_Сapacity_MGN",
        "type": "Integer",
        "fop": "ОП_Количество мест МГН",
        "mge": "МГЭ_Расчетное количество мест для инвалидов",
        "example": "2"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_SmokeNuisance",
        "type": "Text",
        "fop": "ОП_Дымоудаление",
        "mge": "МГЭ_Дымоудаление (Е — естественное, П — принудительное)",
        "example": "Е"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_Safety_MGN",
        "type": "Boolean",
        "fop": "ОП_Зона безопасности МГН",
        "mge": "МГЭ_Зона безопасности МГН",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_Clear",
        "type": "Boolean",
        "fop": "ОП_Чистое помещение",
        "mge": "МГЭ_Чистое помещение (амбулаторно-поликлинические и учебно-воспитательные заведения)",
        "example": "ИСТИНА"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_Type_PP",
        "type": "Text",
        "fop": "ОП_Тип противопожарной преграды",
        "mge": "МГЭ_Тип противопожарной преграды (Л1, Л2, Н1, Н2, Н3 — для лестничных клеток и тамбур-шлюзов)",
        "example": "Н1"
      },
      {
        "pset": "ExpCheck_Space",
        "ifc": "MGE_Fire_zone",
        "type": "Text",
        "fop": "ОП_Номер пожарного отсека",
        "mge": "МГЭ_Номер пожарного отсека (для венткамер и шахт)",
        "example": "ПО-1"
      },
      {
        "pset": "Pset_SpaceCoveringRequirements (если указано в задании на проектирование)",
        "ifc": "FloorCovering",
        "type": "Text",
        "fop": "ОП_Покрытие пола",
        "mge": "Покрытие пола",
        "example": "Керамогранит"
      },
      {
        "pset": "Pset_SpaceCoveringRequirements (если указано в задании на проектирование)",
        "ifc": "FloorCoveringThickness",
        "type": "Real",
        "fop": "ОП_Толщина покрытия пола",
        "mge": "Толщина покрытия пола, мм",
        "example": "20"
      },
      {
        "pset": "Pset_SpaceCoveringRequirements (если указано в задании на проектирование)",
        "ifc": "WallCovering",
        "type": "Text",
        "fop": "ОП_Отделка стен",
        "mge": "Отделка стен",
        "example": "Окраска водно-дисперсионная"
      },
      {
        "pset": "Pset_SpaceCoveringRequirements (если указано в задании на проектирование)",
        "ifc": "WallCoveringThickness",
        "type": "Real",
        "fop": "ОП_Толщина отделки стен",
        "mge": "Толщина отделки стен, мм",
        "example": "2"
      },
      {
        "pset": "Pset_SpaceCoveringRequirements (если указано в задании на проектирование)",
        "ifc": "CeilingCovering",
        "type": "Text",
        "fop": "ОП_Отделка потолка",
        "mge": "Отделка потолка",
        "example": "Гипсокартон с окраской"
      },
      {
        "pset": "Pset_SpaceCoveringRequirements (если указано в задании на проектирование)",
        "ifc": "CeilingCoveringThickness",
        "type": "Real",
        "fop": "ОП_Толщина отделки потолка",
        "mge": "Толщина отделки потолка, мм",
        "example": "15"
      }
    ]
  },
  {
    "title": "Вспомогательное 3D тело (надземная / подземная часть, зона обслуживания)",
    "ifcClass": "IfcBuildingElementProxy",
    "rows": [
      {
        "pset": "ExpCheck_ElementProxy",
        "ifc": "MGE_ElementCode",
        "type": "Text",
        "fop": "ОП_Код по классификатору",
        "mge": "МГЭ_Код элемента (ЭЛ 30 30 10 — подземная часть, ЭЛ 30 30 20 — надземная, ЭЛ 30 30 40 — зона обслуживания оборудования)",
        "example": "ЭЛ 30 30 20"
      },
      {
        "pset": "ExpCheck_ElementProxy",
        "ifc": "MGE_Name",
        "type": "Text",
        "fop": "ADSK_Наименование",
        "mge": "МГЭ_Наименование",
        "example": "Надземная часть"
      }
    ]
  },
  {
    "title": "Стена, перегородка, парапет",
    "ifcClass": "IfcWall",
    "rows": [
      {
        "pset": "Pset_WallCommon",
        "ifc": "LoadBearing",
        "type": "Boolean",
        "fop": "Несущая конструкция",
        "mge": "Признак несущей конструкции",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_WallCommon",
        "ifc": "FireRating",
        "type": "Text",
        "fop": "ОП_Предел огнестойкости",
        "mge": "Предел огнестойкости",
        "example": "REI 150"
      },
      {
        "pset": "Pset_WallCommon",
        "ifc": "Compartmentation",
        "type": "Boolean",
        "fop": "ОП_Противопожарная преграда",
        "mge": "Признак противопожарной преграды",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_WallCommon",
        "ifc": "IsExternal",
        "type": "Boolean",
        "fop": "ОП_Наружный",
        "mge": "Наружный",
        "example": "ИСТИНА"
      },
      {
        "pset": "ExpCheck_Wall",
        "ifc": "MGE_ElementCode",
        "type": "Text",
        "fop": "ОП_Код по классификатору",
        "mge": "МГЭ_Код элемента",
        "example": "ЭЛ 20 10 10"
      },
      {
        "pset": "ExpCheck_Wall",
        "ifc": "MGE_Name",
        "type": "Text",
        "fop": "ADSK_Наименование",
        "mge": "МГЭ_Наименование",
        "example": "Стена наружная несущая"
      },
      {
        "pset": "ExpCheck_Wall",
        "ifc": "MGE_WallType",
        "type": "Text",
        "fop": "ОП_Тип стены",
        "mge": "МГЭ_Тип (рядовая / простенок / парапет)",
        "example": "рядовая"
      },
      {
        "pset": "ExpCheck_Wall",
        "ifc": "MGE_ProductType",
        "type": "Text",
        "fop": "ОП_Тип готового изделия",
        "mge": "МГЭ_Тип готового изделия (Панель стеновая / Блок стеновой)",
        "example": "Панель стеновая"
      },
      {
        "pset": "ExpCheck_Wall",
        "ifc": "MGE_Position",
        "type": "Text",
        "fop": "ADSK_Марка",
        "mge": "МГЭ_Марка элемента",
        "example": "НС-1"
      },
      {
        "pset": "ExpCheck_Wall",
        "ifc": "MGE_Gost",
        "type": "Text",
        "fop": "ADSK_Обозначение",
        "mge": "МГЭ_Обозначение (нормативный документ на изделие)",
        "example": "ГОСТ 11024-2012"
      },
      {
        "pset": "ExpCheck_Wall",
        "ifc": "MGE_Type_PP",
        "type": "Text",
        "fop": "ОП_Тип противопожарной преграды",
        "mge": "МГЭ_Тип противопожарной преграды (если Compartmentation = ИСТИНА)",
        "example": "Противопожарная стена 1-го типа"
      },
      {
        "pset": "IfcMaterialLayer (атрибуты материала)",
        "ifc": "Name",
        "type": "Text",
        "fop": "ОП_Наименование слоя материала",
        "mge": "Наименование слоя материала (код слоя материала по МССК)",
        "example": "Железобетон(СТ 00 15)"
      },
      {
        "pset": "IfcMaterialLayer (атрибуты материала)",
        "ifc": "LayerThickness",
        "type": "Real",
        "fop": "ОП_Толщина слоя",
        "mge": "Толщина слоя, мм",
        "example": "300"
      }
    ]
  },
  {
    "title": "Фасад, навесной фасад, витраж",
    "ifcClass": "IfcCurtainWall",
    "rows": [
      {
        "pset": "Pset_CurtainWallCommon",
        "ifc": "FireRating",
        "type": "Text",
        "fop": "ОП_Предел огнестойкости",
        "mge": "Предел огнестойкости",
        "example": "EI 30"
      },
      {
        "pset": "Pset_CurtainWallCommon",
        "ifc": "Combustible",
        "type": "Boolean",
        "fop": "ОП_Признак горючести",
        "mge": "Признак горючести",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "Pset_CurtainWallCommon",
        "ifc": "SurfaceSpreadOfFlame",
        "type": "Text",
        "fop": "ОП_Распространение пламени",
        "mge": "Распространение пламени (только для горючих материалов)",
        "example": "РП1"
      },
      {
        "pset": "Pset_CurtainWallCommon",
        "ifc": "IsExternal",
        "type": "Boolean",
        "fop": "ОП_Наружный",
        "mge": "Наружный",
        "example": "ИСТИНА"
      },
      {
        "pset": "ExpCheck_CurtainWall",
        "ifc": "MGE_ElementCode",
        "type": "Text",
        "fop": "ОП_Код по классификатору",
        "mge": "МГЭ_Код элемента",
        "example": "ЭЛ 30 40 10"
      },
      {
        "pset": "ExpCheck_CurtainWall",
        "ifc": "MGE_Name",
        "type": "Text",
        "fop": "ADSK_Наименование",
        "mge": "МГЭ_Наименование",
        "example": "Витраж стоечно-ригельный"
      },
      {
        "pset": "ExpCheck_CurtainWall",
        "ifc": "MGE_Position",
        "type": "Text",
        "fop": "ADSK_Марка",
        "mge": "МГЭ_Марка элемента",
        "example": "В-1"
      },
      {
        "pset": "ExpCheck_CurtainWall",
        "ifc": "MGE_Gost",
        "type": "Text",
        "fop": "ADSK_Обозначение",
        "mge": "МГЭ_Обозначение",
        "example": "ГОСТ Р 55780-2013"
      },
      {
        "pset": "ExpCheck_CurtainWall",
        "ifc": "MGE_MaterialCode",
        "type": "Text",
        "fop": "ОП_Код материала",
        "mge": "МГЭ_Код материала (по МССК «Строительные изделия и материалы»)",
        "example": "СТ 10 10"
      },
      {
        "pset": "ExpCheck_CurtainWall",
        "ifc": "MGE_Material",
        "type": "Text",
        "fop": "ОП_Материал",
        "mge": "МГЭ_Наименование материала",
        "example": "Алюминиевый профиль"
      },
      {
        "pset": "IfcMaterialLayer (атрибуты материала)",
        "ifc": "Name",
        "type": "Text",
        "fop": "ОП_Наименование слоя материала",
        "mge": "Наименование слоя материала",
        "example": "Стекло(СТ 05 10)"
      },
      {
        "pset": "IfcMaterialLayer (атрибуты материала)",
        "ifc": "LayerThickness",
        "type": "Real",
        "fop": "ОП_Толщина слоя",
        "mge": "Толщина слоя, мм",
        "example": "4"
      }
    ]
  },
  {
    "title": "Перекрытие (этажа, кровли, лестничной клетки, фундаментная плита)",
    "ifcClass": "IfcSlab",
    "rows": [
      {
        "pset": "Pset_SlabCommon",
        "ifc": "FireRating",
        "type": "Text",
        "fop": "ОП_Предел огнестойкости",
        "mge": "Предел огнестойкости",
        "example": "REI 60"
      },
      {
        "pset": "Pset_SlabCommon",
        "ifc": "LoadBearing",
        "type": "Boolean",
        "fop": "Несущая конструкция",
        "mge": "Признак несущей конструкции",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_SlabCommon",
        "ifc": "Compartmentation",
        "type": "Boolean",
        "fop": "ОП_Противопожарная преграда",
        "mge": "Признак противопожарной преграды",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "Pset_SlabCommon",
        "ifc": "IsExternal",
        "type": "Boolean",
        "fop": "ОП_Наружный",
        "mge": "Наружный",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "ExpCheck_Slab",
        "ifc": "MGE_ElementCode",
        "type": "Text",
        "fop": "ОП_Код по классификатору",
        "mge": "МГЭ_Код элемента",
        "example": "ЭЛ 20 20 10"
      },
      {
        "pset": "ExpCheck_Slab",
        "ifc": "MGE_SlabType",
        "type": "Text",
        "fop": "ОП_Назначение перекрытия",
        "mge": "МГЭ_Назначение (FLOOR / ROOF / LANDING / BASESLAB / USERDEFINED / NOTDEFINED)",
        "example": "FLOOR"
      },
      {
        "pset": "ExpCheck_Slab",
        "ifc": "MGE_Name",
        "type": "Text",
        "fop": "ADSK_Наименование",
        "mge": "МГЭ_Наименование",
        "example": "Перекрытие межэтажное"
      },
      {
        "pset": "ExpCheck_Slab",
        "ifc": "MGE_Position",
        "type": "Text",
        "fop": "ADSK_Марка",
        "mge": "МГЭ_Марка элемента",
        "example": "П-1"
      },
      {
        "pset": "ExpCheck_Slab",
        "ifc": "MGE_Gost",
        "type": "Text",
        "fop": "ADSK_Обозначение",
        "mge": "МГЭ_Обозначение",
        "example": "ГОСТ 9561-2016"
      },
      {
        "pset": "ExpCheck_Slab",
        "ifc": "MGE_Type_PP",
        "type": "Text",
        "fop": "ОП_Тип противопожарной преграды",
        "mge": "МГЭ_Тип противопожарной преграды",
        "example": "Перекрытие противопожарное 2-го типа"
      },
      {
        "pset": "IfcMaterialLayer (атрибуты материала)",
        "ifc": "Name",
        "type": "Text",
        "fop": "ОП_Наименование слоя материала",
        "mge": "Наименование слоя материала",
        "example": "Железобетон(СТ 00 15)"
      },
      {
        "pset": "IfcMaterialLayer (атрибуты материала)",
        "ifc": "LayerThickness",
        "type": "Real",
        "fop": "ОП_Толщина слоя",
        "mge": "Толщина слоя, мм",
        "example": "220"
      }
    ]
  },
  {
    "title": "Покрытие, отделка (полы, потолки, облицовка)",
    "ifcClass": "IfcCovering",
    "rows": [
      {
        "pset": "Pset_CoveringCommon",
        "ifc": "Combustible",
        "type": "Boolean",
        "fop": "ОП_Признак горючести",
        "mge": "Признак горючести",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "Pset_CoveringCommon",
        "ifc": "FlammabilityRating",
        "type": "Text",
        "fop": "ОП_Воспламеняемость",
        "mge": "Воспламеняемость (для горючих материалов)",
        "example": "В1"
      },
      {
        "pset": "Pset_CoveringCommon",
        "ifc": "FragilityRating",
        "type": "Text",
        "fop": "ОП_Группа горючести",
        "mge": "Горючесть (для горючих материалов)",
        "example": "Г1"
      },
      {
        "pset": "Pset_CoveringCommon",
        "ifc": "SurfaceSpreadOfFlame",
        "type": "Text",
        "fop": "ОП_Распространение пламени",
        "mge": "Распространение пламени",
        "example": "РП1"
      },
      {
        "pset": "Pset_CoveringCommon",
        "ifc": "IsExternal",
        "type": "Boolean",
        "fop": "ОП_Наружный",
        "mge": "Наружный",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "ExpCheck_Covering",
        "ifc": "MGE_ElementCode",
        "type": "Text",
        "fop": "ОП_Код по классификатору",
        "mge": "МГЭ_Код элемента",
        "example": "ЭЛ 30 10 10"
      },
      {
        "pset": "ExpCheck_Covering",
        "ifc": "MGE_CoveringType",
        "type": "Text",
        "fop": "ОП_Назначение покрытия",
        "mge": "МГЭ_Назначение (CEILING / FLOORING / CLADDING / ROOFING / MOLDING / SKIRTINGBOARD / INSULATION / MEMBRANE / SLEEVING / WRAPPING)",
        "example": "FLOORING"
      },
      {
        "pset": "ExpCheck_Covering",
        "ifc": "MGE_Name",
        "type": "Text",
        "fop": "ADSK_Наименование",
        "mge": "МГЭ_Наименование",
        "example": "Пол из керамогранита"
      },
      {
        "pset": "ExpCheck_Covering",
        "ifc": "MGE_Gost",
        "type": "Text",
        "fop": "ADSK_Обозначение",
        "mge": "МГЭ_Обозначение",
        "example": "ГОСТ 6787-2001"
      },
      {
        "pset": "ExpCheck_Covering",
        "ifc": "MGE_MaterialCode",
        "type": "Text",
        "fop": "ОП_Код материала",
        "mge": "МГЭ_Код материала",
        "example": "СТ 05 10"
      },
      {
        "pset": "ExpCheck_Covering",
        "ifc": "MGE_Material",
        "type": "Text",
        "fop": "ОП_Материал",
        "mge": "МГЭ_Наименование материала",
        "example": "Керамогранит"
      },
      {
        "pset": "IfcMaterialLayer (атрибуты материала)",
        "ifc": "Name",
        "type": "Text",
        "fop": "ОП_Наименование слоя материала",
        "mge": "Наименование слоя материала",
        "example": "Керамогранит(СТ 05 10)"
      },
      {
        "pset": "IfcMaterialLayer (атрибуты материала)",
        "ifc": "LayerThickness",
        "type": "Real",
        "fop": "ОП_Толщина слоя",
        "mge": "Толщина слоя, мм",
        "example": "10"
      }
    ]
  },
  {
    "title": "Колонна, пилон, арка, база, капитель",
    "ifcClass": "IfcColumn",
    "rows": [
      {
        "pset": "Pset_ColumnCommon",
        "ifc": "LoadBearing",
        "type": "Boolean",
        "fop": "Несущая конструкция",
        "mge": "Признак несущей конструкции",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_ColumnCommon",
        "ifc": "FireRating",
        "type": "Text",
        "fop": "ОП_Предел огнестойкости",
        "mge": "Предел огнестойкости",
        "example": "R 120"
      },
      {
        "pset": "Pset_ColumnCommon",
        "ifc": "IsExternal",
        "type": "Boolean",
        "fop": "ОП_Наружный",
        "mge": "Наружный",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "ExpCheck_Column",
        "ifc": "MGE_ElementCode",
        "type": "Text",
        "fop": "ОП_Код по классификатору",
        "mge": "МГЭ_Код элемента",
        "example": "ЭЛ 20 30 10"
      },
      {
        "pset": "ExpCheck_Column",
        "ifc": "MGE_Name",
        "type": "Text",
        "fop": "ADSK_Наименование",
        "mge": "МГЭ_Наименование",
        "example": "Колонна ж/б 400х400"
      },
      {
        "pset": "ExpCheck_Column",
        "ifc": "MGE_Position",
        "type": "Text",
        "fop": "ADSK_Марка",
        "mge": "МГЭ_Марка элемента",
        "example": "К-1"
      },
      {
        "pset": "ExpCheck_Column",
        "ifc": "MGE_Gost",
        "type": "Text",
        "fop": "ADSK_Обозначение",
        "mge": "МГЭ_Обозначение",
        "example": "ГОСТ 25628-90"
      },
      {
        "pset": "ExpCheck_Column",
        "ifc": "MGE_MaterialCode",
        "type": "Text",
        "fop": "ОП_Код материала",
        "mge": "МГЭ_Код материала",
        "example": "СТ 00 15"
      },
      {
        "pset": "ExpCheck_Column",
        "ifc": "MGE_Material",
        "type": "Text",
        "fop": "ОП_Материал",
        "mge": "МГЭ_Наименование материала",
        "example": "Железобетон В25"
      }
    ]
  },
  {
    "title": "Дверь, ворота, люк",
    "ifcClass": "IfcDoor",
    "rows": [
      {
        "pset": "Pset_DoorCommon",
        "ifc": "SecurityRating",
        "type": "Text",
        "fop": "ОП_Класс устойчивости к взлому",
        "mge": "Класс устойчивости к взлому (по заданию на проектирование)",
        "example": "М3"
      },
      {
        "pset": "Pset_DoorCommon",
        "ifc": "DurabilityRating",
        "type": "Text",
        "fop": "ОП_Устойчивость к разрушающим воздействиям",
        "mge": "Устойчивость к разрушающим воздействиям (по заданию)",
        "example": "3"
      },
      {
        "pset": "Pset_DoorCommon",
        "ifc": "GlazingAreaFraction",
        "type": "Real",
        "fop": "ОП_Процент остекления",
        "mge": "Процент остекления (доля площади остекления от площади полотна)",
        "example": "0.25"
      },
      {
        "pset": "Pset_DoorCommon",
        "ifc": "HandicapAccessible",
        "type": "Boolean",
        "fop": "ОП_Доступность МГН",
        "mge": "Признак МГН",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_DoorCommon",
        "ifc": "FireRating",
        "type": "Text",
        "fop": "ОП_Предел огнестойкости",
        "mge": "Предел огнестойкости",
        "example": "EI 60"
      },
      {
        "pset": "Pset_DoorCommon",
        "ifc": "FireExit",
        "type": "Boolean",
        "fop": "ОП_Путь эвакуации",
        "mge": "Путь эвакуации",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_DoorCommon",
        "ifc": "HasDrive",
        "type": "Boolean",
        "fop": "ОП_Автоматическое открытие",
        "mge": "Автоматическое открытие",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "Pset_DoorCommon",
        "ifc": "SelfClosing",
        "type": "Boolean",
        "fop": "ОП_Автоматическое закрытие",
        "mge": "Автоматическое закрытие",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_DoorCommon",
        "ifc": "IsExternal",
        "type": "Boolean",
        "fop": "ОП_Наружный",
        "mge": "Наружный",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "Pset_DoorWindowGlazingType (для дверей с остеклением)",
        "ifc": "GlassLayers",
        "type": "Integer",
        "fop": "ОП_Количество слоев стекла",
        "mge": "Количество слоев стекол (1 — одно стекло, 2 — однокамерный, 3 — двухкамерный стеклопакет)",
        "example": "2"
      },
      {
        "pset": "Pset_DoorWindowGlazingType (для дверей с остеклением)",
        "ifc": "FillGas",
        "type": "Text",
        "fop": "ОП_Газ-заполнитель камеры",
        "mge": "Наименование газа-заполнителя камеры (воздух / аргон / криптон)",
        "example": "аргон"
      },
      {
        "pset": "Pset_DoorWindowGlazingType (для дверей с остеклением)",
        "ifc": "IsLaminated",
        "type": "Boolean",
        "fop": "ОП_Ламинирование стекла",
        "mge": "Ламинирование (триплекс)",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "Pset_DoorWindowGlazingType (для дверей с остеклением)",
        "ifc": "IsWired",
        "type": "Boolean",
        "fop": "ОП_Армирование стекла",
        "mge": "Армирование",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "Pset_DoorWindowGlazingType (для дверей с остеклением)",
        "ifc": "IsCoated",
        "type": "Boolean",
        "fop": "ОП_С решеткой",
        "mge": "С решеткой",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "ExpCheck_Door",
        "ifc": "MGE_ElementCode",
        "type": "Text",
        "fop": "ОП_Код по классификатору",
        "mge": "МГЭ_Код элемента",
        "example": "ЭЛ 30 20 10"
      },
      {
        "pset": "ExpCheck_Door",
        "ifc": "MGE_Name",
        "type": "Text",
        "fop": "ADSK_Наименование",
        "mge": "МГЭ_Наименование",
        "example": "Дверь противопожарная двупольная"
      },
      {
        "pset": "ExpCheck_Door",
        "ifc": "MGE_Position",
        "type": "Text",
        "fop": "ADSK_Марка",
        "mge": "МГЭ_Марка элемента",
        "example": "Д-1"
      },
      {
        "pset": "ExpCheck_Door",
        "ifc": "MGE_Gost",
        "type": "Text",
        "fop": "ADSK_Обозначение",
        "mge": "МГЭ_Обозначение",
        "example": "ГОСТ 31173-2016"
      },
      {
        "pset": "ExpCheck_Door",
        "ifc": "MGE_MaterialCode1",
        "type": "Text",
        "fop": "ОП_Код материала профиля",
        "mge": "МГЭ_Код материала профиля",
        "example": "СТ 10 05"
      },
      {
        "pset": "ExpCheck_Door",
        "ifc": "MGE_Material1",
        "type": "Text",
        "fop": "ОП_Материал профиля",
        "mge": "МГЭ_Наименование материала профиля",
        "example": "Сталь"
      },
      {
        "pset": "ExpCheck_Door",
        "ifc": "MGE_MaterialCode2",
        "type": "Text",
        "fop": "ОП_Код материала полотна",
        "mge": "МГЭ_Код материала полотна",
        "example": "СТ 10 05"
      },
      {
        "pset": "ExpCheck_Door",
        "ifc": "MGE_Material2",
        "type": "Text",
        "fop": "ОП_Материал полотна",
        "mge": "МГЭ_Наименование материала полотна",
        "example": "Стальной лист"
      },
      {
        "pset": "ExpCheck_Door",
        "ifc": "MGE_Compartmentation",
        "type": "Boolean",
        "fop": "ОП_Противопожарная преграда",
        "mge": "МГЭ_Признак противопожарной преграды",
        "example": "ИСТИНА"
      },
      {
        "pset": "ExpCheck_Door",
        "ifc": "MGE_Type_PP",
        "type": "Text",
        "fop": "ОП_Тип противопожарной преграды",
        "mge": "МГЭ_Тип противопожарной преграды",
        "example": "Дверь противопожарная 2-го типа"
      },
      {
        "pset": "ExpCheck_Door",
        "ifc": "MGE_GlazedDoor",
        "type": "Boolean",
        "fop": "ОП_С остеклением",
        "mge": "МГЭ_С остеклением",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "ExpCheck_Door",
        "ifc": "MGE_OperationType",
        "type": "Text",
        "fop": "ОП_Тип открывания двери",
        "mge": "МГЭ_Тип открывания двери (Приложение Д)",
        "example": "DOUBLE_DOOR_SINGLE_SWING"
      },
      {
        "pset": "ExpCheck_Door",
        "ifc": "MGE_CrossingHeight",
        "type": "Real",
        "fop": "ОП_Высота порога",
        "mge": "МГЭ_Высота порога, мм",
        "example": "20"
      }
    ]
  },
  {
    "title": "Окно, балконный блок",
    "ifcClass": "IfcWindow",
    "rows": [
      {
        "pset": "Pset_WindowCommon",
        "ifc": "GlazingAreaFraction",
        "type": "Real",
        "fop": "ОП_Площадь остекления",
        "mge": "Площадь остекления, м²",
        "example": "1.2"
      },
      {
        "pset": "Pset_WindowCommon",
        "ifc": "FireExit",
        "type": "Boolean",
        "fop": "ОП_Путь эвакуации",
        "mge": "Путь эвакуации",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "Pset_WindowCommon",
        "ifc": "HasDrive",
        "type": "Boolean",
        "fop": "ОП_Автоматическое открытие",
        "mge": "Автоматическое открытие",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "Pset_WindowCommon",
        "ifc": "SelfClosing",
        "type": "Boolean",
        "fop": "ОП_Автоматическое закрытие",
        "mge": "Автоматическое закрытие",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "Pset_WindowCommon",
        "ifc": "IsExternal",
        "type": "Boolean",
        "fop": "ОП_Наружный",
        "mge": "Наружный",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_DoorWindowGlazingType",
        "ifc": "GlassLayers",
        "type": "Integer",
        "fop": "ОП_Количество слоев стекла",
        "mge": "Количество слоев стекла",
        "example": "3"
      },
      {
        "pset": "Pset_DoorWindowGlazingType",
        "ifc": "FillGas",
        "type": "Text",
        "fop": "ОП_Газ-заполнитель камеры",
        "mge": "Наименование газа-заполнителя камеры",
        "example": "аргон"
      },
      {
        "pset": "Pset_DoorWindowGlazingType",
        "ifc": "IsLaminated",
        "type": "Boolean",
        "fop": "ОП_Ламинирование стекла",
        "mge": "Ламинирование (триплекс)",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_DoorWindowGlazingType",
        "ifc": "IsWired",
        "type": "Boolean",
        "fop": "ОП_Армирование стекла",
        "mge": "Армирование",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "Pset_DoorWindowGlazingType",
        "ifc": "IsCoated",
        "type": "Boolean",
        "fop": "ОП_С решеткой",
        "mge": "С решеткой",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "ExpCheck_Window",
        "ifc": "MGE_ElementCode",
        "type": "Text",
        "fop": "ОП_Код по классификатору",
        "mge": "МГЭ_Код элемента",
        "example": "ЭЛ 30 20 20"
      },
      {
        "pset": "ExpCheck_Window",
        "ifc": "MGE_Name",
        "type": "Text",
        "fop": "ADSK_Наименование",
        "mge": "МГЭ_Наименование",
        "example": "Окно ПВХ с двухкамерным стеклопакетом"
      },
      {
        "pset": "ExpCheck_Window",
        "ifc": "MGE_Position",
        "type": "Text",
        "fop": "ADSK_Марка",
        "mge": "МГЭ_Марка элемента",
        "example": "ОК-1"
      },
      {
        "pset": "ExpCheck_Window",
        "ifc": "MGE_Gost",
        "type": "Text",
        "fop": "ADSK_Обозначение",
        "mge": "МГЭ_Обозначение",
        "example": "ГОСТ 30674-99"
      },
      {
        "pset": "ExpCheck_Window",
        "ifc": "MGE_ConstructionType",
        "type": "Text",
        "fop": "ОП_Тип конструкции окна",
        "mge": "МГЭ_Тип конструкции (Алюминий / Сталь / Дерево / Пластик и др.)",
        "example": "Пластик"
      },
      {
        "pset": "ExpCheck_Window",
        "ifc": "MGE_WindowType",
        "type": "Text",
        "fop": "ОП_Тип окна",
        "mge": "МГЭ_Тип окна (WINDOW / SKYLIGHT / LIGHTDOME)",
        "example": "WINDOW"
      },
      {
        "pset": "ExpCheck_Window",
        "ifc": "MGE_PartitioningType",
        "type": "Text",
        "fop": "ОП_Тип створок",
        "mge": "МГЭ_Тип створок (Приложение Е)",
        "example": "DoublePanelVertical"
      },
      {
        "pset": "ExpCheck_Window",
        "ifc": "MGE_ExplodeEasy",
        "type": "Boolean",
        "fop": "ОП_Легкосбрасываемое",
        "mge": "МГЭ_Легкосбрасываемое",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "ExpCheck_Window",
        "ifc": "MGE_Compartmentation",
        "type": "Boolean",
        "fop": "ОП_Противопожарная преграда",
        "mge": "МГЭ_Признак противопожарной преграды",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "ExpCheck_Window",
        "ifc": "MGE_Type_PP",
        "type": "Text",
        "fop": "ОП_Тип противопожарной преграды",
        "mge": "МГЭ_Тип противопожарной преграды (только для противопожарных окон)",
        "example": "Окно противопожарное 1-го типа"
      },
      {
        "pset": "ExpCheck_Window",
        "ifc": "MGE_SillHeight",
        "type": "Real",
        "fop": "ОП_Высота подоконника",
        "mge": "МГЭ_Высота подоконника от чистового пола, мм",
        "example": "900"
      },
      {
        "pset": "ExpCheck_Window",
        "ifc": "MGE_LightTransmission",
        "type": "Text",
        "fop": "ОП_Светопропускание",
        "mge": "МГЭ_Светопропускание (класс по ГОСТ 23166-99 п. 4.7.4)",
        "example": "К2"
      }
    ]
  },
  {
    "title": "Лестница",
    "ifcClass": "IfcStair",
    "rows": [
      {
        "pset": "Pset_StairCommon",
        "ifc": "FireRating",
        "type": "Text",
        "fop": "ОП_Предел огнестойкости",
        "mge": "Предел огнестойкости",
        "example": "REI 60"
      },
      {
        "pset": "Pset_StairCommon",
        "ifc": "NumberOfRiser",
        "type": "Integer",
        "fop": "ОП_Количество подступенков",
        "mge": "Количество подступенков, шт",
        "example": "11"
      },
      {
        "pset": "Pset_StairCommon",
        "ifc": "NumberOfTreads",
        "type": "Integer",
        "fop": "ОП_Количество ступеней",
        "mge": "Количество ступеней, шт",
        "example": "10"
      },
      {
        "pset": "Pset_StairCommon",
        "ifc": "WaistThickness",
        "type": "Real",
        "fop": "ОП_Ширина марша",
        "mge": "Ширина лестницы (марша), мм",
        "example": "1350"
      },
      {
        "pset": "Pset_StairCommon",
        "ifc": "RiserHeight",
        "type": "Real",
        "fop": "ОП_Высота подступенка",
        "mge": "Высота подступенка, мм",
        "example": "150"
      },
      {
        "pset": "Pset_StairCommon",
        "ifc": "TreadLength",
        "type": "Real",
        "fop": "ОП_Глубина ступени",
        "mge": "Глубина ступени, мм",
        "example": "300"
      },
      {
        "pset": "Pset_StairCommon",
        "ifc": "HandicapAccessible",
        "type": "Boolean",
        "fop": "ОП_Доступность МГН",
        "mge": "Признак МГН",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "Pset_StairCommon",
        "ifc": "LoadBearing",
        "type": "Boolean",
        "fop": "Несущая конструкция",
        "mge": "Признак несущей конструкции",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_StairCommon",
        "ifc": "FireExit",
        "type": "Boolean",
        "fop": "ОП_Путь эвакуации",
        "mge": "Путь эвакуации",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_StairCommon",
        "ifc": "IsExternal",
        "type": "Boolean",
        "fop": "ОП_Наружный",
        "mge": "Наружный",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "ExpCheck_Stair",
        "ifc": "MGE_ElementCode",
        "type": "Text",
        "fop": "ОП_Код по классификатору",
        "mge": "МГЭ_Код элемента",
        "example": "ЭЛ 20 40 10"
      },
      {
        "pset": "ExpCheck_Stair",
        "ifc": "MGE_Name",
        "type": "Text",
        "fop": "ADSK_Наименование",
        "mge": "МГЭ_Наименование",
        "example": "Лестница 2-х маршевая"
      },
      {
        "pset": "ExpCheck_Stair",
        "ifc": "MGE_StairFlightType",
        "type": "Text",
        "fop": "ОП_Форма марша",
        "mge": "МГЭ_Форма марша (ПРЯМОЙ / ВИНТОВОЙ / СПИРАЛЬНЫЙ / КРИВОЛИНЕЙНЫЙ)",
        "example": "ПРЯМОЙ"
      },
      {
        "pset": "ExpCheck_Stair",
        "ifc": "MGE_Position",
        "type": "Text",
        "fop": "ADSK_Марка",
        "mge": "МГЭ_Марка элемента",
        "example": "ЛМ-1"
      },
      {
        "pset": "ExpCheck_Stair",
        "ifc": "MGE_Gost",
        "type": "Text",
        "fop": "ADSK_Обозначение",
        "mge": "МГЭ_Обозначение",
        "example": "ГОСТ 9818-2015"
      },
      {
        "pset": "ExpCheck_Stair",
        "ifc": "MGE_MaterialCode",
        "type": "Text",
        "fop": "ОП_Код материала",
        "mge": "МГЭ_Код материала",
        "example": "СТ 00 15"
      },
      {
        "pset": "ExpCheck_Stair",
        "ifc": "MGE_Material",
        "type": "Text",
        "fop": "ОП_Материал",
        "mge": "МГЭ_Наименование материала",
        "example": "Железобетон"
      },
      {
        "pset": "ExpCheck_Stair",
        "ifc": "MGE_Layout",
        "type": "Text",
        "fop": "ОП_Назначение лестницы",
        "mge": "МГЭ_Назначение (ВНЕШНЯЯ / ВНУТРЕННЯЯ ОТКРЫТАЯ / ВНУТРЕННЯЯ ЗАКРЫТАЯ / НАРУЖНАЯ / ВНУТРИКВАРТИРНАЯ)",
        "example": "ВНУТРЕННЯЯ ЗАКРЫТАЯ"
      },
      {
        "pset": "ExpCheck_Stair",
        "ifc": "MGE_Section",
        "type": "Text",
        "fop": "ADSK_Номер секции",
        "mge": "МГЭ_Секция",
        "example": "Секция 1"
      }
    ]
  },
  {
    "title": "Лестничный марш",
    "ifcClass": "IfcStairFlight",
    "rows": [
      {
        "pset": "Pset_StairFlightCommon",
        "ifc": "FireRating",
        "type": "Text",
        "fop": "ОП_Предел огнестойкости",
        "mge": "Предел огнестойкости",
        "example": "REI 60"
      },
      {
        "pset": "Pset_StairFlightCommon",
        "ifc": "NumberOfRiser",
        "type": "Integer",
        "fop": "ОП_Количество подступенков",
        "mge": "Количество подступенков, шт",
        "example": "11"
      },
      {
        "pset": "Pset_StairFlightCommon",
        "ifc": "NumberOfTreads",
        "type": "Integer",
        "fop": "ОП_Количество ступеней",
        "mge": "Количество ступеней, шт",
        "example": "10"
      },
      {
        "pset": "Pset_StairFlightCommon",
        "ifc": "RiserHeight",
        "type": "Real",
        "fop": "ОП_Высота подступенка",
        "mge": "Высота подступенка, мм",
        "example": "150"
      },
      {
        "pset": "Pset_StairFlightCommon",
        "ifc": "TreadLength",
        "type": "Real",
        "fop": "ОП_Глубина ступени",
        "mge": "Глубина ступени, мм",
        "example": "300"
      },
      {
        "pset": "Pset_StairFlightCommon",
        "ifc": "WaistThickness",
        "type": "Real",
        "fop": "ОП_Ширина марша",
        "mge": "Ширина лестницы, мм",
        "example": "1350"
      },
      {
        "pset": "Pset_StairFlightCommon",
        "ifc": "HandicapAccessible",
        "type": "Boolean",
        "fop": "ОП_Доступность МГН",
        "mge": "Признак МГН",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "Pset_StairFlightCommon",
        "ifc": "LoadBearing",
        "type": "Boolean",
        "fop": "Несущая конструкция",
        "mge": "Признак несущей конструкции",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_StairFlightCommon",
        "ifc": "FireExit",
        "type": "Boolean",
        "fop": "ОП_Путь эвакуации",
        "mge": "Путь эвакуации",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_StairFlightCommon",
        "ifc": "IsExternal",
        "type": "Boolean",
        "fop": "ОП_Наружный",
        "mge": "Наружный",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "ExpCheck_StairFlight",
        "ifc": "MGE_ElementCode",
        "type": "Text",
        "fop": "ОП_Код по классификатору",
        "mge": "МГЭ_Код элемента",
        "example": "ЭЛ 20 40 10"
      },
      {
        "pset": "ExpCheck_StairFlight",
        "ifc": "MGE_Name",
        "type": "Text",
        "fop": "ADSK_Наименование",
        "mge": "МГЭ_Наименование",
        "example": "Лестничный марш"
      },
      {
        "pset": "ExpCheck_StairFlight",
        "ifc": "MGE_StairFlightType",
        "type": "Text",
        "fop": "ОП_Форма марша",
        "mge": "МГЭ_Форма марша",
        "example": "ПРЯМОЙ"
      },
      {
        "pset": "ExpCheck_StairFlight",
        "ifc": "MGE_Position",
        "type": "Text",
        "fop": "ADSK_Марка",
        "mge": "МГЭ_Марка элемента",
        "example": "ЛМ-1"
      },
      {
        "pset": "ExpCheck_StairFlight",
        "ifc": "MGE_Gost",
        "type": "Text",
        "fop": "ADSK_Обозначение",
        "mge": "МГЭ_Обозначение",
        "example": "ГОСТ 9818-2015"
      },
      {
        "pset": "ExpCheck_StairFlight",
        "ifc": "MGE_MaterialCode",
        "type": "Text",
        "fop": "ОП_Код материала",
        "mge": "МГЭ_Код материала",
        "example": "СТ 00 15"
      },
      {
        "pset": "ExpCheck_StairFlight",
        "ifc": "MGE_Material",
        "type": "Text",
        "fop": "ОП_Материал",
        "mge": "МГЭ_Наименование материала",
        "example": "Железобетон"
      },
      {
        "pset": "ExpCheck_StairFlight",
        "ifc": "MGE_Layout",
        "type": "Text",
        "fop": "ОП_Назначение лестницы",
        "mge": "МГЭ_Назначение",
        "example": "ВНУТРЕННЯЯ ЗАКРЫТАЯ"
      },
      {
        "pset": "ExpCheck_StairFlight",
        "ifc": "MGE_Section",
        "type": "Text",
        "fop": "ADSK_Номер секции",
        "mge": "МГЭ_Секция",
        "example": "Секция 1"
      }
    ]
  },
  {
    "title": "Пандус, рампа",
    "ifcClass": "IfcRamp",
    "rows": [
      {
        "pset": "Pset_RampCommon",
        "ifc": "FireRating",
        "type": "Text",
        "fop": "ОП_Предел огнестойкости",
        "mge": "Предел огнестойкости",
        "example": "REI 60"
      },
      {
        "pset": "Pset_RampCommon",
        "ifc": "RequiredHeadroom",
        "type": "Real",
        "fop": "ОП_Высота проезда",
        "mge": "Высота проезда/прохода, мм",
        "example": "2100"
      },
      {
        "pset": "Pset_RampCommon",
        "ifc": "RequiredSlope",
        "type": "Integer",
        "fop": "ОП_Уклон",
        "mge": "Уклон (угол подъема от горизонтали), градусы",
        "example": "5"
      },
      {
        "pset": "Pset_RampCommon",
        "ifc": "HandicapAccessible",
        "type": "Boolean",
        "fop": "ОП_Доступность МГН",
        "mge": "Признак МГН",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_RampCommon",
        "ifc": "LoadBearing",
        "type": "Boolean",
        "fop": "Несущая конструкция",
        "mge": "Признак несущей конструкции",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_RampCommon",
        "ifc": "FireExit",
        "type": "Boolean",
        "fop": "ОП_Путь эвакуации",
        "mge": "Путь эвакуации",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_RampCommon",
        "ifc": "IsExternal",
        "type": "Boolean",
        "fop": "ОП_Наружный",
        "mge": "Наружный",
        "example": "ИСТИНА"
      },
      {
        "pset": "ExpCheck_Ramp",
        "ifc": "MGE_ElementCode",
        "type": "Text",
        "fop": "ОП_Код по классификатору",
        "mge": "МГЭ_Код элемента",
        "example": "ЭЛ 20 50 10"
      },
      {
        "pset": "ExpCheck_Ramp",
        "ifc": "MGE_Name",
        "type": "Text",
        "fop": "ADSK_Наименование",
        "mge": "МГЭ_Наименование",
        "example": "Пандус при входе"
      },
      {
        "pset": "ExpCheck_Ramp",
        "ifc": "MGE_RampFlightType",
        "type": "Text",
        "fop": "ОП_Форма марша",
        "mge": "МГЭ_Форма марша (ПРЯМОЙ / ВИНТОВОЙ / СПИРАЛЬНЫЙ / КРИВОЛИНЕЙНЫЙ)",
        "example": "ПРЯМОЙ"
      },
      {
        "pset": "ExpCheck_Ramp",
        "ifc": "MGE_Position",
        "type": "Text",
        "fop": "ADSK_Марка",
        "mge": "МГЭ_Марка элемента",
        "example": "ПД-1"
      },
      {
        "pset": "ExpCheck_Ramp",
        "ifc": "MGE_Gost",
        "type": "Text",
        "fop": "ADSK_Обозначение",
        "mge": "МГЭ_Обозначение",
        "example": ""
      },
      {
        "pset": "ExpCheck_Ramp",
        "ifc": "MGE_MaterialCode",
        "type": "Text",
        "fop": "ОП_Код материала",
        "mge": "МГЭ_Код материала",
        "example": "СТ 00 15"
      },
      {
        "pset": "ExpCheck_Ramp",
        "ifc": "MGE_Material",
        "type": "Text",
        "fop": "ОП_Материал",
        "mge": "МГЭ_Наименование материала",
        "example": "Железобетон"
      },
      {
        "pset": "ExpCheck_Ramp",
        "ifc": "MGE_Section",
        "type": "Text",
        "fop": "ADSK_Номер секции",
        "mge": "МГЭ_Секция",
        "example": "Секция 1"
      }
    ]
  },
  {
    "title": "Марш пандуса, рампы",
    "ifcClass": "IfcRampFlight",
    "rows": [
      {
        "pset": "Pset_RampFlightCommon",
        "ifc": "FireRating",
        "type": "Text",
        "fop": "ОП_Предел огнестойкости",
        "mge": "Предел огнестойкости",
        "example": "REI 60"
      },
      {
        "pset": "Pset_RampFlightCommon",
        "ifc": "RequiredHeadroom",
        "type": "Real",
        "fop": "ОП_Высота проезда",
        "mge": "Высота проезда/прохода, мм",
        "example": "2100"
      },
      {
        "pset": "Pset_RampFlightCommon",
        "ifc": "RequiredSlope",
        "type": "Integer",
        "fop": "ОП_Уклон",
        "mge": "Уклон, градусы",
        "example": "5"
      },
      {
        "pset": "Pset_RampFlightCommon",
        "ifc": "HandicapAccessible",
        "type": "Boolean",
        "fop": "ОП_Доступность МГН",
        "mge": "Признак МГН",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_RampFlightCommon",
        "ifc": "LoadBearing",
        "type": "Boolean",
        "fop": "Несущая конструкция",
        "mge": "Признак несущей конструкции",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_RampFlightCommon",
        "ifc": "FireExit",
        "type": "Boolean",
        "fop": "ОП_Путь эвакуации",
        "mge": "Путь эвакуации",
        "example": "ИСТИНА"
      },
      {
        "pset": "Pset_RampFlightCommon",
        "ifc": "IsExternal",
        "type": "Boolean",
        "fop": "ОП_Наружный",
        "mge": "Наружный",
        "example": "ИСТИНА"
      },
      {
        "pset": "ExpCheck_RampFlight",
        "ifc": "MGE_ElementCode",
        "type": "Text",
        "fop": "ОП_Код по классификатору",
        "mge": "МГЭ_Код элемента",
        "example": "ЭЛ 20 50 10"
      },
      {
        "pset": "ExpCheck_RampFlight",
        "ifc": "MGE_Name",
        "type": "Text",
        "fop": "ADSK_Наименование",
        "mge": "МГЭ_Наименование",
        "example": "Марш пандуса"
      },
      {
        "pset": "ExpCheck_RampFlight",
        "ifc": "MGE_RampFlightType",
        "type": "Text",
        "fop": "ОП_Форма марша",
        "mge": "МГЭ_Форма марша",
        "example": "ПРЯМОЙ"
      },
      {
        "pset": "ExpCheck_RampFlight",
        "ifc": "MGE_Position",
        "type": "Text",
        "fop": "ADSK_Марка",
        "mge": "МГЭ_Марка элемента",
        "example": "ПД-1"
      },
      {
        "pset": "ExpCheck_RampFlight",
        "ifc": "MGE_Gost",
        "type": "Text",
        "fop": "ADSK_Обозначение",
        "mge": "МГЭ_Обозначение",
        "example": ""
      },
      {
        "pset": "ExpCheck_RampFlight",
        "ifc": "MGE_MaterialCode",
        "type": "Text",
        "fop": "ОП_Код материала",
        "mge": "МГЭ_Код материала",
        "example": "СТ 00 15"
      },
      {
        "pset": "ExpCheck_RampFlight",
        "ifc": "MGE_Material",
        "type": "Text",
        "fop": "ОП_Материал",
        "mge": "МГЭ_Наименование материала",
        "example": "Железобетон"
      },
      {
        "pset": "ExpCheck_RampFlight",
        "ifc": "MGE_Section",
        "type": "Text",
        "fop": "ADSK_Номер секции",
        "mge": "МГЭ_Секция",
        "example": "Секция 1"
      }
    ]
  },
  {
    "title": "Ограждение, поручень (кроме парапетов)",
    "ifcClass": "IfcRailing",
    "rows": [
      {
        "pset": "Pset_RailingCommon",
        "ifc": "Height",
        "type": "Real",
        "fop": "ADSK_Размер_Высота",
        "mge": "Высота ограждения, мм",
        "example": "1200"
      },
      {
        "pset": "Pset_RailingCommon",
        "ifc": "Diameter",
        "type": "Real",
        "fop": "ADSK_Размер_Диаметр",
        "mge": "Характерный размер (например, диаметр поручня), мм",
        "example": "50"
      },
      {
        "pset": "Pset_RailingCommon",
        "ifc": "IsExternal",
        "type": "Boolean",
        "fop": "ОП_Наружный",
        "mge": "Наружный",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "ExpCheck_Railing",
        "ifc": "MGE_ElementCode",
        "type": "Text",
        "fop": "ОП_Код по классификатору",
        "mge": "МГЭ_Код элемента (раздел «Ограждающие элементы»)",
        "example": "ЭЛ 20 60 10"
      },
      {
        "pset": "ExpCheck_Railing",
        "ifc": "MGE_Name",
        "type": "Text",
        "fop": "ADSK_Наименование",
        "mge": "МГЭ_Наименование",
        "example": "Ограждение лестницы"
      },
      {
        "pset": "ExpCheck_Railing",
        "ifc": "MGE_Position",
        "type": "Text",
        "fop": "ADSK_Марка",
        "mge": "МГЭ_Марка элемента",
        "example": "О-1"
      },
      {
        "pset": "ExpCheck_Railing",
        "ifc": "MGE_Gost",
        "type": "Text",
        "fop": "ADSK_Обозначение",
        "mge": "МГЭ_Обозначение",
        "example": "ГОСТ 25772-83"
      },
      {
        "pset": "ExpCheck_Railing",
        "ifc": "MGE_HandicapAccessible",
        "type": "Boolean",
        "fop": "ОП_Доступность МГН",
        "mge": "МГЭ_Признак МГН",
        "example": "ИСТИНА"
      },
      {
        "pset": "ExpCheck_Railing",
        "ifc": "MGE_MaterialCode",
        "type": "Text",
        "fop": "ОП_Код материала",
        "mge": "МГЭ_Код материала",
        "example": "СТ 10 05"
      },
      {
        "pset": "ExpCheck_Railing",
        "ifc": "MGE_Material",
        "type": "Text",
        "fop": "ОП_Материал",
        "mge": "МГЭ_Наименование материала",
        "example": "Сталь"
      },
      {
        "pset": "ExpCheck_Railing",
        "ifc": "MGE_Section",
        "type": "Text",
        "fop": "ADSK_Номер секции",
        "mge": "МГЭ_Секция",
        "example": "Секция 1"
      }
    ]
  },
  {
    "title": "Сборка (лестницы, фермы, каркасы)",
    "ifcClass": "IfcElementAssembly",
    "rows": [
      {
        "pset": "ExpCheck_Assembly",
        "ifc": "MGE_AssemblyCode",
        "type": "Text",
        "fop": "ОП_Код сборки",
        "mge": "МГЭ_Код сборки (по МССК «Элементы»)",
        "example": "ЭЛ 20 40 00"
      },
      {
        "pset": "ExpCheck_Assembly",
        "ifc": "MGE_Name",
        "type": "Text",
        "fop": "ADSK_Наименование",
        "mge": "МГЭ_Наименование сборки",
        "example": "Лестница в сборе"
      },
      {
        "pset": "ExpCheck_Assembly",
        "ifc": "MGE_IsExternal",
        "type": "Boolean",
        "fop": "ОП_Наружный",
        "mge": "МГЭ_Наружный",
        "example": "ЛОЖЬ"
      },
      {
        "pset": "ExpCheck_Assembly",
        "ifc": "MGE_AssemblyPlace",
        "type": "Text",
        "fop": "ОП_Тип сборки",
        "mge": "МГЭ_Тип сборки (SITE — на площадке / FACTORY — заводская / NOTDEFINED)",
        "example": "FACTORY"
      },
      {
        "pset": "ExpCheck_Assembly",
        "ifc": "MGE_Position",
        "type": "Text",
        "fop": "ADSK_Марка",
        "mge": "МГЭ_Марка элемента",
        "example": "С-1"
      },
      {
        "pset": "ExpCheck_Assembly",
        "ifc": "MGE_Gost",
        "type": "Text",
        "fop": "ADSK_Обозначение",
        "mge": "МГЭ_Обозначение",
        "example": ""
      }
    ]
  }
];
