import { useEffect, useRef, useState } from "react";
import { Cat, X } from "lucide-react";
import catBaseUrl from "@/assets/cat-base.webp";
import catBlinkUrl from "@/assets/cat-blink.webp";

const BLUE = "#2563eb";
const BLUE_DARK = "#60a5fa";
const SIZE = 180; // px, ширина котика
const STORAGE_KEY = "cat-enabled";

const CURSOR_SVG = (c: string) =>
  `<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22">
    <path d="M4 2 L4 18 L8.4 13.8 L11 20 L13.6 18.6 L11 12.6 L16.8 12.6 Z" fill="${c}" stroke="white" stroke-width="1.2"/>
  </svg>`;

const dataUri = (svg: string) => `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;

function isTouchDevice(): boolean {
  return typeof window !== "undefined" &&
    (window.matchMedia("(pointer: coarse)").matches || "ontouchstart" in window);
}

/**
 * Реалистичный аниме-котик (сгенерированное изображение), который гоняется
 * за курсором: пружинная физика, разворот по направлению, наклоны,
 * подпрыгивания, дыхание, моргание, мягкая тень.
 */
export function CursorCat() {
  const [enabled, setEnabled] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    const saved = window.localStorage.getItem(STORAGE_KEY);
    return saved === null ? true : saved === "1";
  });
  const catRef = useRef<HTMLDivElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);
  const shadowRef = useRef<HTMLDivElement>(null);
  const touch = isTouchDevice();

  // синяя стрелка-курсор
  useEffect(() => {
    if (touch) return;
    const apply = () => {
      const dark = document.documentElement.classList.contains("dark");
      document.body.style.cursor = dataUri(CURSOR_SVG(dark ? BLUE_DARK : BLUE)) + " 2 2, auto";
    };
    apply();
    const obs = new MutationObserver(apply);
    obs.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
    return () => {
      obs.disconnect();
      document.body.style.cursor = "";
    };
  }, [touch]);

  useEffect(() => {
    if (touch || !enabled) return;
    const el = catRef.current;
    const img = imgRef.current;
    const sh = shadowRef.current;
    if (!el || !img) return;
    el.style.display = "block";
    if (sh) sh.style.display = "block";

    // предзагрузка кадра моргания, чтобы смена была мгновенной
    const pre = new Image();
    pre.src = catBlinkUrl;

    let tx = window.innerWidth / 2, ty = window.innerHeight / 2;
    let x = tx, y = ty, vx = 0, vy = 0, raf = 0, t = 0;
    let blinking = false;
    let nextBlink = 2 + Math.random() * 3, blinkUntil = 0;

    const onMove = (e: MouseEvent) => { tx = e.clientX; ty = e.clientY; };
    window.addEventListener("mousemove", onMove);

    const loop = () => {
      t += 1 / 60;
      const k = 0.035, damp = 0.88;
      vx = (vx + (tx - x) * k) * damp;
      vy = (vy + (ty - y) * k) * damp;
      x += vx; y += vy;
      const speed = Math.hypot(vx, vy);

      // моргание: каждые 2–6 секунд на ~0,15 с
      if (t > nextBlink) { blinkUntil = t + 0.15; nextBlink = t + 2 + Math.random() * 4; }
      const shouldBlink = t < blinkUntil;
      if (shouldBlink !== blinking) {
        blinking = shouldBlink;
        img.src = blinking ? catBlinkUrl : catBaseUrl;
      }

      // живость: дыхание, покачивание на месте, подпрыгивание в движении
      const hop = speed > 1 ? Math.abs(Math.sin(t * 10)) * Math.min(18, 4 + speed * 0.5) : 0;
      const idleBob = speed <= 1 ? Math.sin(t * 3) * 3 : 0;
      const breathing = speed <= 1 ? Math.sin(t * 2.2) : 0;
      const rot = Math.max(-16, Math.min(16, vx * 0.7)) + (speed <= 1 ? Math.sin(t * 1.7) * 2 : 0);
      const flip = vx < -0.4 ? -1 : 1;
      // squash-and-stretch: растягивается в прыжке, дышит в покое
      const squash = speed > 1 ? 1 + Math.sin(t * 10) * 0.04 : 1 + breathing * 0.012;
      el.style.transform =
        `translate(${x - SIZE / 2}px, ${y - SIZE - 10 - hop - idleBob}px) ` +
        `rotate(${rot}deg) scaleX(${flip}) scaleY(${squash})`;

      // тень: уменьшается и бледнеет в прыжке
      if (sh) {
        const lift = Math.min(1, (hop + Math.max(0, idleBob)) / 24);
        const sc = 1 - lift * 0.35;
        sh.style.transform = `translate(${x - 45}px, ${y - 14}px) scale(${sc})`;
        sh.style.opacity = String(0.28 - lift * 0.14);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      window.removeEventListener("mousemove", onMove);
      cancelAnimationFrame(raf);
      el.style.display = "none";
      if (sh) sh.style.display = "none";
    };
  }, [enabled, touch]);

  const toggle = () => {
    const next = !enabled;
    setEnabled(next);
    window.localStorage.setItem(STORAGE_KEY, next ? "1" : "0");
  };

  if (touch) return null;

  return (
    <>
      <div
        ref={shadowRef}
        aria-hidden="true"
        style={{
          position: "fixed", top: 0, left: 0, width: 90, height: 16,
          borderRadius: "50%", background: "radial-gradient(ellipse at center, rgba(15,23,42,0.55) 0%, rgba(15,23,42,0) 70%)",
          pointerEvents: "none", zIndex: 9998, display: "none", willChange: "transform",
        }}
      />
      <div
        ref={catRef}
        aria-hidden="true"
        style={{
          position: "fixed", top: 0, left: 0, width: SIZE, height: SIZE,
          pointerEvents: "none", zIndex: 9999, display: "none", willChange: "transform",
        }}
      >
        <img
          ref={imgRef}
          src={catBaseUrl}
          alt=""
          draggable={false}
          style={{ width: "100%", height: "100%", objectFit: "contain", userSelect: "none" }}
        />
      </div>
      <button
        type="button"
        onClick={toggle}
        aria-label={enabled ? "Отключить котика" : "Включить котика"}
        title={enabled ? "Отключить котика" : "Включить котика"}
        className={`fixed bottom-4 left-4 z-50 inline-flex h-9 items-center gap-1.5 rounded-md border px-3 text-xs font-medium shadow-sm transition-colors ${
          enabled
            ? "border-blue-600 bg-blue-600 text-white hover:bg-blue-500"
            : "border-slate-200 bg-white text-slate-500 hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400 dark:hover:bg-slate-800"
        }`}
      >
        {enabled ? <Cat className="h-4 w-4" /> : <X className="h-4 w-4" />}
        {enabled ? "Котик вкл" : "Котик выкл"}
      </button>
    </>
  );
}
